<?php
/*  
 * Analysis Console for Intrusion Databases (ACID)
 *
 * Author: Roman Danyliw <rdd@cert.org>, <roman@danyliw.com>
 *
 * Copyright (C) 2000, 2001 Carnegie Mellon University
 * (see the file 'acid_main.php' for license details)
 *
 * Purpose:   
 *
 * Input GET/POST variables
 *   - submit:
 *   - time:
 *   - time_sep:
 */

function StoreAlertNum($sql, $label, $time_sep, $i_year, $i_month, $i_day, $i_hour)
{  
  GLOBAL $db, $cnt, $label_lst, $value_lst, $value_POST_lst, $debug_mode;

  $label_lst [ $cnt ] = $label;

  if ( $debug_mode > 0 )
     echo $sql."<BR>";

  $result = $db->acidExecute($sql);
  if ( $myrow = $result->acidFetchRow() )
  {
     $value_lst [ $cnt ] = $myrow[0];
     $result->acidFreeRows();

     $value_POST_lst[$cnt] = "acid_qry_main.php?new=1&submit=Query+DB&num_result_rows=-1&time_cnt=1".
                             "&time%5B0%5D%5B0%5D=+&time%5B0%5D%5B1%5D=%3D";

     if ( $time_sep[0] == "hour" )
        $value_POST_lst[$cnt] = $value_POST_lst[$cnt].'&time%5B0%5D%5B2%5D='.$i_month.
                                '&time%5B0%5D%5B3%5D='.$i_day.
                                '&time%5B0%5D%5B4%5D='.$i_year.
                                '&time%5B0%5D%5B5%5D='.$i_hour;

     else if ( $time_sep[0] == "day" )
        $value_POST_lst[$cnt] = $value_POST_lst[$cnt].'&time%5B0%5D%5B2%5D='.$i_month.
                                '&time%5B0%5D%5B3%5D='.$i_day.
                                '&time%5B0%5D%5B4%5D='.$i_year;

     else if ( $time_sep[0] == "month" )
        $value_POST_lst[$cnt] = $value_POST_lst[$cnt].'&time%5B0%5D%5B2%5D='.$i_month.
                                '&time%5B0%5D%5B4%5D='.$i_year;

     /* add no parentheses and no operator */
     $value_POST_lst[$cnt] = $value_POST_lst[$cnt].'&time%5B0%5D%5B8%5D=+&time%5B0%5D%5B9%5D=+';
 
     $cnt++;
  }
  else
     $value_lst [ $cnt++ ] = 0;
}

function PrintTimeProfile()
{
   GLOBAL $cnt, $label_lst, $value_lst, $value_POST_lst;

   /* find max value */
   $max_cnt = $value_lst[0];
   for ( $i = 0; $i < $cnt; $i++ )
       if ( $value_lst[$i] > $max_cnt )  $max_cnt = $value_lst[$i];

   echo '<TABLE BORDER=1 WIDTH="100%">
           <TR><TD CLASS="plfieldhdr">Time</TD>
               <TD CLASS="plfieldhdr"># of Alerts</TD>
               <TD CLASS="plfieldhdr">Alerts</TD></TR>';


   for ($i = 0; $i < $cnt; $i++ )
   {
       if ($value_lst[$i] == 0)
          $entry_width = 0;
       else
          $entry_width = round($value_lst[$i]/$max_cnt*100);

       if ($entry_width > 0 )
          $entry_color = "#FF0000";
       else
          $entry_color = "#FFFFFF";

       echo '<TR>
                 <TD>';

       if ( $value_lst[$i] == 0 ) 
          echo $label_lst[$i];
       else
          echo '<A HREF="'.$value_POST_lst[$i].'">'.$label_lst[$i].'</A>';

       echo     '</TD>
                 <TD ALIGN=CENTER>'.$value_lst[$i].'</TD>
                 <TD><TABLE WIDTH="100%">
                      <TR>
                       <TD BGCOLOR="'.$entry_color.'" WIDTH="'.$entry_width.'%">&nbsp;</TD>
                       <TD></TD>
                      </TR>
                     </TABLE>
                 </TD>
             </TR>';
    }
    echo '</TABLE>';
}

  include ("acid_constants.inc");
  include ("acid_include.inc");
  include ("acid_conf.php");
  include_once ("acid_db_common.php");
  include_once ("acid_common.php");
  include_once ("acid_stat_common.php");
  include_once ("acid_qry_common.php");

  $time_sep = ImportHTTPVar("time_sep");
  $time = ImportHTTPVar("time");
  $submit = ImportHTTPVar("submit");

  $cs = new CriteriaState("acid_stat_alerts.php");
  $cs->ReadState();

  $page_title = "Time Profile of Alerts";
  PrintACIDSubHeader($page_title, $page_title, "Back");

  /* Connect to the Alert database */
  $db = NewACIDDBConnection($DBlib_path, $DBtype);
  $db->acidDBConnect($db_connect_method,
                     $alert_dbname, $alert_host, $alert_port, $alert_user, $alert_password);

  $criteria_clauses = ProcessCriteria();
  PrintCriteria("");

  $from = " FROM acid_event ".$criteria_clauses[0];
  $where = " WHERE ".$criteria_clauses[1];

  if ( $event_cache_auto_update == 1 )  UpdateAlertCache($db);

  if ( $submit == "" )
  {
   InitArray($time, $MAX_ROWS, TIME_CFCNT, "");
  }

  echo '<FORM ACTION="acid_stat_time.php" METHOD="post">
        <TABLE WIDTH="100%" BORDER=0>
         <TR>
          <TD WIDTH="40%" CLASS="metatitle"><B><FONT COLOR="#FFFFFF">Time Criteria</FONT></B></TD>
          <TD></TD></TR>
        </TABLE>

        <TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">
        <TR>
         <TD>';

  echo '<B>Profile by :</B> &nbsp;
        <INPUT NAME="time_sep[0]" TYPE="radio" VALUE="hour" '.chk_check($time_sep[0],"hour").'> Hour
        <INPUT NAME="time_sep[0]" TYPE="radio" VALUE="day" '.chk_check($time_sep[0], "day").'> Day
        <INPUT NAME="time_sep[0]" TYPE="radio" VALUE="month" '.chk_check($time_sep[0], "month").'> Month
        <BR>';

  echo '<SELECT NAME="time_sep[1]">
         <OPTION VALUE=" "  '.chk_select($time_sep[1], " ").'>{ time }
         <OPTION VALUE="on" '.chk_select($time_sep[1], "on").'>on
         <OPTION VALUE="between"'.chk_select($time_sep[1], "between").'>between
        </SELECT>';
 
  for ( $i = 0; $i < 2; $i++ )
  {
      echo '<SELECT NAME="time['.$i.'][0]">
             <OPTION VALUE=" "  '.chk_select($time[$i][0]," " ).'>{ month }
             <OPTION VALUE="01" '.chk_select($time[$i][0],"01").'>Jan
             <OPTION VALUE="02" '.chk_select($time[$i][0],"02").'>Feb
             <OPTION VALUE="03" '.chk_select($time[$i][0],"03").'>Mar
             <OPTION VALUE="04" '.chk_select($time[$i][0],"04").'>Apr
             <OPTION VALUE="05" '.chk_select($time[$i][0],"05").'>May
             <OPTION VALUE="06" '.chk_select($time[$i][0],"06").'>Jun
             <OPTION VALUE="07" '.chk_select($time[$i][0],"07").'>Jly
             <OPTION VALUE="08" '.chk_select($time[$i][0],"08").'>Aug
             <OPTION VALUE="09" '.chk_select($time[$i][0],"09").'>Sep
             <OPTION VALUE="10" '.chk_select($time[$i][0],"10").'>Oct
             <OPTION VALUE="11" '.chk_select($time[$i][0],"11").'>Nov
             <OPTION VALUE="12" '.chk_select($time[$i][0],"12").'>Dec
            </SELECT>';
      
      echo '<INPUT TYPE="text" NAME="time['.$i.'][1]" SIZE=2 VALUE="'.$time[$i][1].'"> &nbsp;'."\n";
      echo '<SELECT NAME="time['.$i.'][2]">
             <OPTION VALUE=" "    '.chk_select($time[$i][2]," ").'>{ year }
             <OPTION VALUE="1999" '.chk_select($time[$i][2],"1999").'>1999
             <OPTION VALUE="2000" '.chk_select($time[$i][2],"2000").'>2000
             <OPTION VALUE="2001" '.chk_select($time[$i][2],"2001").'>2001
             <OPTION VALUE="2002" '.chk_select($time[$i][2],"2002").'>2002
            </SELECT>';

      if ( $i == 0 ) echo '&nbsp; -- &nbsp;&nbsp;';
  }

  echo '<INPUT TYPE="submit" NAME="submit" VALUE="Profile Alert">
        </TD></TR></TABLE>
        </FORM>

        <P><HR>';

  if ( $submit != "" && $time_sep[0] == "" )
     echo '<FONT><B>No profiling criteria was specified!</B>  Click on "hour", "day", or "month"
           to choose the granularity of the aggregate statistics.</FONT>';     
  else if ( $submit != "" && $time_sep[1] == " " )
     echo '<FONT><B>The type of time parameter which will be passed was not specified!</B>  Choose either
           "on", to specify a single date, or "between" to specify an interval.</FONT>';

  else if ( $submit != "" && $time_sep[0] != "" && $time_sep[1] == "on" &&
            $time[0][2] == " " )
     echo '<FONT><B>No Year parameter was specified!</B></FONT>';

  else if ( $submit != "" && $time_sep[0] != "" && $time_sep[1] == "between" &&
            ($time[1][2] == " " || $time[0][2] == " ") )
     echo '<FONT><B>No Year parameter was specified!</B></FONT>';

  else if ( $submit != "" && $time_sep[0] != "" && $time_sep[1] == "between" &&
            ($time[1][0] == " " || $time[0][0] == " ") )
     echo '<FONT><B>No Month parameter was specified!</B></FONT>'; 
 
  else if ( $submit != "" && ($time_sep[0] != "") 
            && $time_sep[1] == "between" && ($time[1][1] == "" || $time[0][1] == "") )
     echo '<FONT><B>No Day parameter was specified!</B></FONT>';

  else if ($submit != "")
  {

  /* Dump the results of the above specified query */
           
  $year_start = $year_end = NULL;
  $month_start = $month_end = NULL;
  $day_start = $day_end = NULL;
  $hour_start = $hour_end = NULL;

  if ( $time_sep[1] == "between" )
  {
     if ($time_sep[0] == "hour")       
     { 
        $year_start = $time[0][2];  $year_end = $time[1][2];
        $month_start = $time[0][0]; $month_end = $time[1][0];
        $day_start = $time[0][1]; $day_end = $time[1][1];
        $hour_start = 0; $hour_end = 23; 
     }
     else if ($time_sep[0] == "day")          
     { 
        $year_start = $time[0][2];  $year_end = $time[1][2];
        $month_start = $time[0][0]; $month_end = $time[1][0];
        $day_start = $time[0][1]; $day_end = $time[1][1];
        $hour_start = -1; 
     }
     else if ($time_sep[0] == "month")           
     { 
        $year_start = $time[0][2];  $year_end = $time[1][2];
        $month_start = $time[0][0]; $month_end = $time[1][0];
        $day_start = -1;
        $hour_start = -1; 
     }
  }
  else if ( $time_sep[1] == "on" )
  {
     if ($time_sep[0] == "hour")       
     { 
        $year_start = $time[0][2];  $year_end = $time[0][2];
        if ( $time[0][0] != " " )
        {   $month_start = $time[0][0]; $month_end = $time[0][0];  }
        else
        {   $month_start = 1; $month_end = 12;  }

        if ( $time[0][1] != "" )
        {  $day_start = $time[0][1]; $day_end = $time[0][1];  }
        else
        {  $day_start = 1; $day_end = 31;  }
        $hour_start = 0; $hour_end = 23; 
     }
     else if ($time_sep[0] == "day")          
     { 
        $year_start = $time[0][2];  $year_end = $time[0][2];
        if ( $time[0][0] != " " )
        {   $month_start = $time[0][0]; $month_end = $time[0][0];  }
        else
        {   $month_start = 1; $month_end = 12;  }

        if ( $time[0][1] != "" )
        {  $day_start = $time[0][1]; $day_end = $time[0][1];  }
        else
        {  $day_start = 1; $day_end = 31;  }

        $hour_start = -1; 
     }
     else if ($time_sep[0] == "month")           
     { 
        $year_start = $time[0][2];  $year_end = $time[0][2];
        if ( $time[0][0] != " " )
        {   $month_start = $time[0][0]; $month_end = $time[0][0];  }
        else
        {   $month_start = 1; $month_end = 12;  }  
        $day_start = -1;
        $hour_start = -1; 
     }
  }

  if ( $debug_mode == 1 )
  {
     echo '<TABLE BORDER=1>
            <TR>
              <TD>year_start<TD>year_end<TD>month_start<TD>month_end
              <TD>day_start<TD>day_end<TD>hour_start<TD>hour_end
            <TR>
              <TD>'.$year_start.'<TD>'.$year_end.'<TD>'.$month_start.'<TD>'.$month_end.
              '<TD>'.$day_start.'<TD>'.$day_end.'<TD>'.$hour_start.'<TD>'.$hour_end.
           '</TABLE>';
  }

  $cnt = 0;
  $i_year = $i_month = $i_day = $i_hour = NULL;

  for ( $i_year = $year_start; $i_year <= $year_end; $i_year++ )
  {
      $sql = "SELECT count(*) ".$from.$where." AND ".
             $db->acidSQL_YEAR("timestamp", "=", $i_year);

      if ( $month_start != -1 )
      {
         if ($i_year == $year_start)  $month_start2 = $month_start;  else  $month_start2 = 1;
         if ($i_year == $year_end)    $month_end2 = $month_end;      else  $month_end2 = 12;

         for ( $i_month = $month_start2; $i_month <= $month_end2; $i_month++ )
         {
             $sql = "SELECT count(*) ".$from.$where." AND ".
                    $db->acidSQL_YEAR("timestamp", "=", $i_year)." AND ".
                    $db->acidSQL_MONTH("timestamp", "=", $i_month);

             if ( $day_start != -1 )
             {
                if ($i_month == $month_start)  $day_start2 = $day_start;  else  $day_start2 = 1;
                if ($i_month == $month_end)    $day_end2 = $day_end;      else  $day_end2 = 31;

                for ( $i_day = $day_start2; $i_day <= $day_end2; $i_day++ )
                {
                  if ( checkdate($i_month, $i_day, $i_year) )
                  {
                    $sql = "SELECT count(*) ".$from.$where." AND ".
                           $db->acidSQL_YEAR("timestamp", "=", $i_year)." AND ".
                           $db->acidSQL_MONTH("timestamp", "=",$i_month)." AND ".
                           $db->acidSQL_DAY("timestamp", "=", $i_day);

                    $i_hour = "";
                    if ( $hour_start != -1 )
                    {
                       for ( $i_hour = $hour_start; $i_hour <= $hour_end; $i_hour++ )
                       {
                           $sql = "SELECT count(*) ".$from.$where." AND ".
                                  $db->acidSQL_YEAR("timestamp", "=", $i_year)." AND ".
                                  $db->acidSQL_MONTH("timestamp", "=", $i_month)." AND ".
                                  $db->acidSQL_DAY("timestamp", "=", $i_day)." AND ".
                                  $db->acidSQL_HOUR("timestamp", "=", $i_hour);

                           StoreAlertNum($sql, $i_month."/".$i_day."/".$i_year." ".
                                               $i_hour.":00:00 - ".$i_hour.":59:59", 
                                         $time_sep, $i_year, $i_month, $i_day, $i_hour);
                       }  // end hour
                    }
                    else
                        StoreAlertNum($sql, $i_month."/".$i_day."/".$i_year,
                                      $time_sep, $i_year, $i_month, $i_day, $i_hour);
                  }
                }   // end day
             }
             else
               StoreAlertNum($sql, $i_month."/".$i_year, $time_sep, $i_year, $i_month, $i_day, $i_hour);
         }   // end month
      }
      else
        StoreAlertNum($sql, $i_year, $time_sep, $i_year, $i_month, $i_day, $i_hour);
  }   // end year

  echo '</TABLE>';
  PrintTimeProfile();
  }

//  $db->acidClose();
  
  PrintACIDSubFooter();
?>
