<?php
/*  
 * Analysis Console for Intrusion Databases (ACID)
 *
 * Author: Roman Danyliw <rdd@cert.org>, <roman@danyliw.com>
 *
 * Copyright (C) 2000, 2001 Carnegie Mellon University
 * (see the file 'acid_main.php' for license details)
 *
 * Purpose: status and event/dns/whois cache maintenance   
 *
 */

  include("acid_constants.inc");
  include("acid_conf.php");
  include("acid_include.inc");
  include_once("acid_db_common.php");
  include_once("acid_common.php");
  include_once("acid_stat_common.php");

  $et = new EventTiming($debug_time_mode);
  $cs = new CriteriaState("acid_maintenance.php");
  $cs->ReadState();

  $page_title = "Maintenance";
  PrintACIDSubHeader($page_title, $page_title, $cs->GetBackLink());

  $submit = ImportHTTPVar("submit");

?>
<P><P>

<FORM METHOD="POST"
      ACTION="acid_maintenance.php">

<?php
  /* Connect to the Alert database */
  $db = NewACIDDBConnection($DBlib_path, $DBtype);
  $db->acidDBConnect($db_connect_method,
                     $alert_dbname, $alert_host, $alert_port, $alert_user, $alert_password);

  if ( $debug_mode > 0 )
     echo "submit = '$submit'<P>";

  set_time_limit($max_script_runtime);

  if ( $submit == "Update Alert Cache" )
  {
     UpdateAlertCache($db);     
  }
  else if ( $submit == "Rebuild Alert Cache" )
  {
     DropAlertCache($db);
     UpdateAlertCache($db);
  }
  else if ( $submit == "Update IP Cache" )
  {
     UpdateDNSCache($db);     
  }
  else if ( $submit == "Rebuild IP Cache" )
  {
     DropDNSCache($db);
     UpdateDNSCache($db);
  }
  else if ( $submit == "Update Whois Cache" )
  {
     UpdateWhoisCache($db);     
  }
  else if ( $submit == "Rebuild Whois Cache" )
  {
     DropWhoisCache($db);
     UpdateWhoisCache($db);
  }

  echo '<TABLE WIDTH="100%" CELLSPACING=0 CELLPADDING=2 BORDER=0 BGCOLOR="#669999">
         <TR><TD> 
           <TABLE WIDTH="100%" CELLSPACING=0 CELLPADDING=2 BORDER=0 BGCOLOR="#FFFFFF">
              <TR><TD class="sectiontitle">PHP build</TD></TR>
              <TR><TD>
         <B>CLIENT:</B> '.$HTTP_USER_AGENT.'<BR>
         <B>SERVER:</B> '.$SERVER_SOFTWARE.'<BR> 
         <B>SERVER HW:</B> '.php_uname().'<BR>
         <B>PHP VERSION:</B> '.phpversion().'<BR>
         <B>PHP API:</B> '.php_sapi_name().'<BR>';

  $tmp_error_reporting_str = "";

  if ( (ini_get("error_reporting") & E_ERROR) > 0 )
     $tmp_error_reporting_str = $tmp_error_reporting_str." [E_ERROR] ";

  if ( (ini_get("error_reporting") & E_WARNING) > 0 )
     $tmp_error_reporting_str = $tmp_error_reporting_str." [E_WARNING] ";

  if ( (ini_get("error_reporting") & E_PARSE) > 0 )
     $tmp_error_reporting_str = $tmp_error_reporting_str." [E_PARSE] ";

  if ( (ini_get("error_reporting") & E_NOTICE) > 0 )
     $tmp_error_reporting_str = $tmp_error_reporting_str." [E_NOTICE] ";

  if ( (ini_get("error_reporting") & E_CORE_WARNING) > 0 )
     $tmp_error_reporting_str = $tmp_error_reporting_str." [E_CORE_WARNING] ";

  if ( (ini_get("error_reporting") & E_CORE_ERROR) > 0 )
     $tmp_error_reporting_str = $tmp_error_reporting_str." [E_CORE_ERROR] ";

  if ( (ini_get("error_reporting") & E_COMPILE_ERROR) > 0 )
     $tmp_error_reporting_str = $tmp_error_reporting_str." [E_COMPILE_ERROR] ";

  if ( (ini_get("error_reporting") & E_COMPILE_WARNING) > 0 )
     $tmp_error_reporting_str = $tmp_error_reporting_str." [E_COMPILE_WARNING] ";

  echo ' <B>PHP Logging level:</B> ('.ini_get("error_reporting").') '.$tmp_error_reporting_str.'<BR>
         <B>Loaded Modules: </B> ';

         $module_lst = get_loaded_extensions();
         for ( $i = 0; $i < count($module_lst); $i++)
             echo " [ ".$module_lst[$i]." ]";

  echo '      </TD><TR>
           </TABLE>
         </TD></TR>
        </TABLE><P>';

  echo '<TABLE WIDTH="100%" CELLSPACING=0 CELLPADDING=2 BORDER=0 BGCOLOR="#669999">
         <TR><TD> 
           <TABLE WIDTH="100%" CELLSPACING=0 CELLPADDING=2 BORDER=0 BGCOLOR="#FFFFFF">
              <TR><TD class="sectiontitle">Database</TD></TR>
              <TR><TD>';
     
  GLOBAL $ADODB_vers;

  echo "<B>DB Type:</B> $DBtype <BR>  
        <B>DB Abstraction Version:</B> $ADODB_vers <BR>
        <B>ALERT DB Name:</B> $alert_dbname <BR>
        <B>ARCHIVE DB Name:</B> $archive_dbname <BR>

             </TD><TR>
           </TABLE>
         </TD></TR>
        </TABLE><P>";

  echo '<TABLE WIDTH="100%" CELLSPACING=0 CELLPADDING=2 BORDER=0 BGCOLOR="#669999">
         <TR><TD> 
           <TABLE WIDTH="100%" CELLSPACING=0 CELLPADDING=2 BORDER=0 BGCOLOR="#FFFFFF">
              <TR><TD class="sectiontitle">Alert Information Cache</TD></TR>
              <TR><TD>';

  $event_cnt_lst = $db->acidExecute("SELECT COUNT(*) FROM event");
  $event_cnt_row = $event_cnt_lst->acidFetchRow();
  $event_cnt = $event_cnt_row[0];
  $event_cnt_lst->acidFreeRows();

  $cache_event_cnt_lst = $db->acidExecute("SELECT COUNT(*) FROM acid_event");
  $cache_event_cnt_row = $cache_event_cnt_lst->acidFetchRow();
  $cache_event_cnt = $cache_event_cnt_row[0];
  $cache_event_cnt_lst->acidFreeRows();

  echo '<B>Total Events:</B> '.$event_cnt.'&nbsp&nbsp
        <B>Cached Events:</B> '.$cache_event_cnt.'
        &nbsp;&nbsp;
        <INPUT TYPE="submit" NAME="submit" VALUE="Update Alert Cache">
        &nbsp;&nbsp;
        <INPUT TYPE="submit" NAME="submit" VALUE="Rebuild Alert Cache">';

  echo '   </TD><TR>
           </TABLE>
         </TD></TR>
        </TABLE><P>';

  echo '<TABLE WIDTH="100%" CELLSPACING=0 CELLPADDING=2 BORDER=0 BGCOLOR="#669999">
         <TR><TD> 
           <TABLE WIDTH="100%" CELLSPACING=0 CELLPADDING=2 BORDER=0 BGCOLOR="#FFFFFF">
              <TR><TD class="sectiontitle">IP Address Cache</TD></TR>
              <TR><TD>';

  $uncached_sip_cnt = UniqueSrcIPCnt($db);
  $uncached_dip_cnt = UniqueDstIPCnt($db);
  
  $ip_result = $db->acidExecute("SELECT COUNT(DISTINCT ip_src) FROM acid_event ".
                                "INNER JOIN acid_ip_cache ON ipc_ip = ip_src ".
                                "WHERE ipc_fqdn is not NULL");
  $row = $ip_result->acidFetchRow();
  $ip_result->acidFreeRows();
  $cached_sip_cnt = $row[0];

  $ip_result = $db->acidExecute("SELECT COUNT(DISTINCT ip_dst) FROM acid_event ".
                                "INNER JOIN acid_ip_cache ON ipc_ip = ip_dst ".
                                "WHERE ipc_fqdn is not NULL");
  $row = $ip_result->acidFetchRow();
  $ip_result->acidFreeRows();
  $cached_dip_cnt = $row[0];

  $ip_result = $db->acidExecute("SELECT COUNT(DISTINCT ip_src) FROM acid_event ".
                                "INNER JOIN acid_ip_cache ON ipc_ip = ip_src ".
                                "WHERE ipc_whois is not NULL");
  $row = $ip_result->acidFetchRow();
  $ip_result->acidFreeRows();
  $cached_swhois_cnt = $row[0];

  $ip_result = $db->acidExecute("SELECT COUNT(DISTINCT ip_dst) FROM acid_event ".
                                "INNER JOIN acid_ip_cache ON ipc_ip = ip_dst ".
                                "WHERE ipc_whois is not NULL");
  $row = $ip_result->acidFetchRow();
  $ip_result->acidFreeRows();
  $cached_dwhois_cnt = $row[0];

  echo '<B>Unique Src IP:</B> '.$uncached_sip_cnt.'&nbsp;&nbsp&nbsp;'.
       '<B>DNS Cached:</B> '.$cached_sip_cnt.'&nbsp;&nbsp;&nbsp;'.
       '<B>Whois Cached:</B> '.$cached_swhois_cnt.'<BR>'.
       '<B>Unique Dst IP:</B> '.$uncached_dip_cnt.'&nbsp;&nbsp&nbsp;'.
       '<B>DNS Cached:</B> '.$cached_dip_cnt.'&nbsp;&nbsp;&nbsp;'.
       '<B>Whois Cached:</B> '.$cached_dwhois_cnt.'<BR>
        <INPUT TYPE="submit" NAME="submit" VALUE="Update IP Cache">&nbsp;
        <INPUT TYPE="submit" NAME="submit" VALUE="Update Whois Cache"><BR>
        <INPUT TYPE="submit" NAME="submit" VALUE="Rebuild IP Cache">&nbsp;
        <INPUT TYPE="submit" NAME="submit" VALUE="Rebuild Whois Cache"><BR>';
       
  echo '   </TD><TR>
           </TABLE>
         </TD></TR>
        </TABLE><P>';

  $et->PrintTiming();

  echo "\n</FORM>\n";
  
  PrintACIDSubFooter();
?>
