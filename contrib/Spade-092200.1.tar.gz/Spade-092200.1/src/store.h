/*********************************************************************
store.h, distributed as part of Spade v092200.1
Author: James Hoagland, Silicon Defense (hoagland@SiliconDefense.com)
copyright (c) 2000 by Silicon Defense (http://www.silicondefense.com/)
Released under GNU General Public License, see the COPYING file included
with the distribution or http://www.silicondefense.com/spice/ for details.

store.h is the header file for store.c.

Please send complaints, kudos, and especially improvements and bugfixes to
hoagland@SiliconDefense.com.  As described in GNU General Public License, no
warranty is expressed for this program.
*********************************************************************/

/* the current format version # for new statefiles */
#define CUR_FVERS ((unsigned char)1)

int checkpoint(char *filename);
int recover(char *filename);

/* $Id: store.h,v 1.3 2000/09/22 17:43:54 jim Exp $ */
