/*********************************************************************
params.h, distributed as part of Spade v092200.1
Author: James Hoagland, Silicon Defense (hoagland@SiliconDefense.com)
copyright (c) 2000 by Silicon Defense (http://www.silicondefense.com/)
Released under GNU General Public License, see the COPYING file included
with the distribution or http://www.silicondefense.com/spice/ for details.

params.h contains constants that are used for tree memory management in
Spade

Please send complaints, kudos, and especially improvements and bugfixes to
hoagland@SiliconDefense.com.  As described in GNU General Public License, no
warranty is expressed for this program.
*********************************************************************/

#ifndef PARAMS_H
#define PARAMS_H

/* defaults unless recovering from a checkpoint */
#define DEFAULT_ROOT_BLOCK_BITS 10
#define DEFAULT_INT_BLOCK_BITS 9
#define DEFAULT_LEAF_BLOCK_BITS 10

/* these number of blocks are used
   unless file recovering from already uses more blocks */
#define DEFAULT_MAX_ROOT_BLOCKS 4500
#define DEFAULT_MAX_INT_BLOCKS 12000
#define DEFAULT_MAX_LEAF_BLOCKS 9000

#endif

/* $Id: params.h,v 1.2 2000/09/22 17:43:04 jim Exp $ */
