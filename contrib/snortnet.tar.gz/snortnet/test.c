#include <pthread.h>

void main() {

pthread_mutex_t pt = PTHREAD_MUTEX_INITIALIZER;

}
