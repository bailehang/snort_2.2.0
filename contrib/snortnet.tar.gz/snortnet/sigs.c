#include "sncon.h"

void sig_term(int sig) {

	sn_endscr();
	exit(0);
}

void sig_chld(int sig) {
	int  status;
	pid_t pid;

	while((pid=waitpid(-1, &status, WNOHANG)) > 0)
		remove_node_connect(pid, status);
}

void sig_init(void) {

	signal(SIGTERM,sig_term);
	signal(SIGINT,sig_term);
	signal(SIGQUIT,sig_term);
	signal(SIGCHLD,sig_chld);
}
