#ifndef NCURSED_H
#define NCURSED_H
#include "sncon.h"
void            sn_initscr(void);
void            sn_endscr(void);
void sn_connected_status(int, int );

typedef struct _winparam {
	int cols;
	int lines;
} winparam;

#define COLOR_MAIN 1
#define COLOR_NODE 2
#define COLOR_ALARM 3
#define COLOR_ALARMMSG 4
#endif				/* NCURSED_H */
