#ifndef SIGS_H
#define SIGS_H

#include "sncon.h"

void sig_term(int sig);
void sig_init(void);
#endif
