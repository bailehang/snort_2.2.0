#ifndef UTILS_H
#define UTILS_H
#include "sncon.h"
void connects_init(void);
cltnode *cltnodebypid(pid_t);
cltnode *cltnodebyid(int);
int add_cltnode(int, pid_t, unsigned long, unsigned long);
void remove_cltnode(cltnode *);
int            add_node_connect(struct sockaddr_in *, pid_t);
void            remove_node_connect(pid_t, int);
void            refuse_node_connect(struct sockaddr_in *);
void            put_alert(int );
void            display_alert(NetAlert *, struct sockaddr_in *);
void		poll_select(int );
int read_alert( cltnode *);
int write_alert(NetAlert *, struct sockaddr_in *, cltnode *);
char           *addr2str(const void *, char *);
#endif				/* UTILS_H */
